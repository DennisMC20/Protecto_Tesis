<footer class="footer mt-auto py-2 bg-dark">
    <div class="container">
        <p class="text-center">
            <span class="text-white">&copy; <?php echo date('Y'); ?> <a>INFORCA-COMPROMETIDOS CON EL MEDIO AMBIENTE</a></span>
            <span class="text-white">&copy; <?php echo date('Y'); ?> <a>CONTACTANOS///TEL:5831-2746///administracion.planta@inforca.com.gt</a></span>
        </p>
    </div>
</footer>