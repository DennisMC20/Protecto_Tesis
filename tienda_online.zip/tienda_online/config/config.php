<?php



//Configuración del sistema
define("SITE_URL", "http://localhost/tienda_online");
define("KEY_TOKEN", "TIED.DJMC**");
define("MONEDA", "Q");

//Configuración para Paypal
define("CLIENT_ID", "Ac4a2IBRcCWyNssBXlAaW5vl6o1DbvpD19qSU9FLndyNP7y1wtRJEejsp32vnlyPEIVbkbxTViJW-Gn-");
define("CURRENCY", "GTQ");

//Configuración para pagos Credito 
define("TOKEN_MP", "TEST-XXXXXXXXX");
define("PUBLIC_KEY_MP", "TEST-XXXXXXXXX");
define("LOCALE_MP", "es-MXM");
//Configuración para pagos Credito//

//Datos para envio de correo electronico
define("MAIL_HOST", "smtp.gmail.com");//mail.dominio.com
define("MAIL_USER", "tiendaweb02@gmail.com");//correo de empresa para
define("MAIL_PASS", "Tienda23@");//contraseña de la misma
define("MAIL_PORT", "587");//puerto de salida para el correo de direccion gmail 

session_start();

$num_cart = 0;
if (isset($_SESSION['carrito']['productos'])) {
    $num_cart = count($_SESSION['carrito']['productos']);
}
